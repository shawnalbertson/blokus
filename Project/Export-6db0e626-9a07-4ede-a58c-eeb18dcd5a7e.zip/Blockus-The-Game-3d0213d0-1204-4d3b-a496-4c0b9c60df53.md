# Blockus: The Game

> Pranavi Boyalakuntla
Shawn Albertson

## Project Overview

If you would like to play Blokus on your computer locally, this is the project for you! Using this project, you can play Blockus (avoiding copyright infringement) with your friends on one of your computers. You also don't lose any pieces this way!

![](Untitled-db5c7701-8abd-4ace-ad22-9f791a9f7973.png)

Fig 1. An ongoing blockus game between four players. 

In this project, we put together a UI where people could play Blockus with 3 of their friends. Blockus is traditionally a 4 person game where players can place pieces on a board and try to block their opponents from occupying more of the board. More information on the rules of Blokus can be found at: [https://service.mattel.com/instruction_sheets/BJV44-Eng.pdf](https://service.mattel.com/instruction_sheets/BJV44-Eng.pdf)

## Results

In this project, we were able to implement the game of Blockus in a similar way as people would play the game in the physical world. Once a user's turn is finished, the next user's turn is automatically started. Players are unable to place pieces on top of pieces that they have already placed, as shown in figure 1. 

Players are able to select pieces using preset hotkeys. The status of all of their pieces can be viewed by pressing 'c' while one's turn is in play. There are 21 pieces that are able to be played. Once a piece has been played by a user, it will change its status to "played". 

In order to exit this status page, the player can press the hotkey associated with their chosen piece and that piece will then be allowed to be put in play. If a piece has already been used, it will not allow the player to select that piece. If a player decides to change which piece they are playing with this round, they either hit that corresponding key or hit 'c' again to revisit the status page.

![](Untitled-9c2d00c2-8129-4ba7-be7f-b0eda55ac3cd.png)

Fig 2. The status page of all of a player's pieces. This is the status page of the blue player above.

In the game of Blockus, a piece can be rotated and placed in multiple orientations. Players can change the orientation of their pieces by using the left, right, up, and down arrow keys. 

![](Untitled-988eb4dd-a638-4383-86cf-ea36a927793f.png)

Fig 3. Rotating a piece to play it in different orientations.

In order to play a piece, a user first presses the hotkey associated with the piece desired to be placed. This piece will then follow the player's mouse around until the player chooses to place it on the board by clicking it. This will cause the piece to snap to the closest board position and be removed from that player's inventory.

![](Untitled-a84e4463-cae3-4a0a-a52b-348360a79938.png)

Fig 4. A user is able to drag the piece around with their mouse.

## Implementation

![](Untitled-f7c98930-e33a-4167-9bac-2343ecb9763e.png)

Fig 5. UML Class Diagram

The Screen class initializes the pygame screen and is used later to update the screen. The board and all of the pieces are drawn on this screen. The piece inventory screen is also shown on this screen later on. The Tile class serves as the basic building block of the different components of the game. The Tile class loads an image as a pygame object, scales it, and tags it to a color code. Our program uses six Tile instances for different colors and drawing cases. The Tiles class stores the six different Tile objects. 

One of the design decisions we made was in the way we define Board and Piece classes. We decided to use an array in the form of lists of lists with string as the entries, as pictured below. In this representation, each string corresponds to a color that is the same as the color code initialized in Tile. Here, the x's represent a colored piece and the dots symbolize an empty square. This particular array would be a '+' using 5 tiles. 

    [['.', 'x', '.'], ['x', 'x', 'x'], ['.', 'x', '.']]

Pieces are instantiated by a Player object, and the actual color is determined by the player that instantiates the pieces. For each player, all of the possible pieces created at the beginning of the game. Each of these pieces has an 'available' status which keeps track of whether or not a certain player has already played a piece. This functionality is used in the inventory page.

This meant that our Board and our Piece classes could be the same in many ways. Each can look through an array and draw a Tile in the position that correlates with the position of the entry in the array. Because of this, the Piece class inherits the Board class, and makes use of its draw() function.

Another key idea for this structure is the fact that a Piece can modify the board by rewriting some of its entries. That way, the same instance of Board is always drawn, and it just changes over time as pieces get played. When a player moves a piece onto the board and places it, the color of the board underneath that piece is changed. This is done through the modify_board function. When a piece is attempted to be placed on top of another piece, the is_valid function stops that piece from being placed by checking the color of the board underneath it.

These classes are used in play_game.py. First, the load function creates the Screen object, all of the Tile objects, and the base 20x20 Board object with white tiles. The functions your_turn() and place_piece() work together to act as the controller for the game. It runs through the entire mechanism of a turn, including visualizing the piece in place, checking piece inventory, and rotating a piece. Finally, play takes arguments to create four players and cycle through, giving each player a turn.

## Reflection

As a team, we struggled to find an effective system to decide what work needed to be done before heading our separate ways. We didn't meet between the second and third class and ended up creating a lot of the same code in slightly different ways. We wanted to incorporate components from both of our code into one, so we worked to merge our code. This proved to consume a lot of time, and could have been prevented with better planning. 

Despite these challenges, the scope of the project felt appropriate. The construction of the game was heavily structured around classes, which felt like an important step in developing our understanding of Python. With more time, we could certainly implement more features to the game that would make it easier to use. For example, an undo function and the ability to recognize a move that violates the corner rule of blokus would be good additions. Also, once a player cannot make a move they should be able to pass on their turn.